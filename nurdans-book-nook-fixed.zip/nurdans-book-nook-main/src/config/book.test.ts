import { describe, expect, it } from "vitest";
import { BOOK, formatPrice } from "./book";

describe("book offer config", () => {
  it("sells the book for 980 ₽", () => {
    expect(BOOK.price).toBe(980);
    expect(formatPrice(BOOK.price)).toBe("980\u00A0₽");
  });

  it("has a single payment link to Tribute Hn6", () => {
    expect(BOOK.paymentUrl).toBe("https://web.tribute.tg/p/Hn6");
  });

  it("routes support to Telegram @nurdan0808", () => {
    expect(BOOK.support.url).toBe("https://t.me/nurdan0808");
  });
});
