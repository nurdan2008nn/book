/**
 * Главные настройки лендинга. Меняйте цену и ссылки здесь — весь сайт обновится сам.
 */
export const BOOK = {
  title: "Кодекс натурального здоровья",
  subtitle: "150 золотых рецептов природной медицины",
  pages: 170,
  recipes: 150,
  systems: 11,

  /** Цена, ₽ */
  price: 980,
  /** Старая (зачёркнутая) цена, ₽. null — не показывать. */
  oldPrice: null as number | null,
  currency: "₽",

  /** Единственная ссылка на оплату (Tribute) */
  paymentUrl: "https://web.tribute.tg/p/Hn6",

  support: {
    telegram: "nurdan0808",
    url: "https://t.me/nurdan0808",
  },
} as const;

export const formatPrice = (value: number) =>
  `${value.toLocaleString("ru-RU")}\u00A0${BOOK.currency}`;
