import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";

import { Chapters } from "@/components/landing/Chapters";
import { Faq, Footer } from "@/components/landing/Faq";
import { Hero } from "@/components/landing/Hero";
import { Offer } from "@/components/landing/Offer";
import { Audience, Comparison, Highlights, Inside } from "@/components/landing/Sections";
import { StickyBuyBar } from "@/components/landing/StickyBuyBar";

const TITLE = "Кодекс натурального здоровья — 150 рецептов природной медицины (PDF)";
const DESCRIPTION =
  "Электронная книга на 170 страниц: 150 проверенных домашних рецептов для 11 систем организма — точные пропорции, пошаговое приготовление и противопоказания.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const heroRef = useRef<HTMLElement>(null);
  const [showBar, setShowBar] = useState(false);

  useEffect(() => {
    const hero = heroRef.current;
    const buy = document.getElementById("buy");
    if (!hero) return;
    const seen = { hero: true, buy: false };
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (e.target === hero) seen.hero = e.isIntersecting;
        if (e.target === buy) seen.buy = e.isIntersecting;
      }
      // Show the bar once the hero is gone, but hide it over the offer block itself.
      setShowBar(!seen.hero && !seen.buy);
    });
    io.observe(hero);
    if (buy) io.observe(buy);
    return () => io.disconnect();
  }, []);

  return (
    <main>
      <Hero ref={heroRef} />
      <Audience />
      <Comparison />
      <Chapters />
      <Inside />
      <Highlights />
      <Offer />
      <Faq />
      <Footer />
      <StickyBuyBar visible={showBar} />
    </main>
  );
}
