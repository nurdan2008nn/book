import { createFileRoute } from "@tanstack/react-router";

import { LegalPage, LegalSection } from "@/components/landing/LegalPage";
import { BOOK } from "@/config/book";

const TITLE = "Политика конфиденциальности — Кодекс натурального здоровья";
const DESCRIPTION =
  "Как сайт книги «Кодекс натурального здоровья» обращается с данными посетителей: персональные данные не собираются, оплата проходит через Tribute.";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <LegalPage title="Политика конфиденциальности">
      <LegalSection title="1. Общие положения">
        <p>
          Этот сайт носит исключительно информационный характер: он рассказывает об электронной
          книге «{BOOK.title}» и даёт ссылку на страницу оплаты. На сайте нет регистрации, личного
          кабинета, форм обратной связи и подписок.
        </p>
      </LegalSection>

      <LegalSection title="2. Какие данные мы не собираем">
        <p>
          Сайт не собирает, не хранит и не передаёт третьим лицам ваши персональные данные, в том
          числе:
        </p>
        <ul>
          <li>фамилию, имя и отчество;</li>
          <li>номер телефона;</li>
          <li>адрес электронной почты;</li>
          <li>платёжные реквизиты и данные банковских карт.</li>
        </ul>
      </LegalSection>

      <LegalSection title="3. Оплата и получение книги">
        <p>
          Оплата и выдача цифрового товара полностью происходят на стороне сервиса Tribute
          (tribute.tg) и в Telegram. Нажимая кнопку оплаты, вы переходите на страницу Tribute, где
          действуют его собственные правила и политика конфиденциальности. Данные, которые вы
          вводите при оплате, получает и обрабатывает Tribute, а не этот сайт.
        </p>
      </LegalSection>

      <LegalSection title="4. Обезличенная статистика посещений">
        <p>
          Чтобы понимать, насколько сайт удобен, мы смотрим обезличенную статистику посещений.
          Её для нас собирает платформа Lovable, на которой работает сайт. Эта статистика не
          использует cookie-файлы, ничего не сохраняет на вашем устройстве, не хранит IP-адреса и
          не позволяет узнать, кто вы.
        </p>
        <p>Записывается только следующее:</p>
        <ul>
          <li>какие страницы открывались и откуда вы пришли на сайт;</li>
          <li>страна, браузер, операционная система и тип устройства;</li>
          <li>сколько времени вы провели на сайте, как быстро загружались страницы и ошибки;</li>
          <li>нажатия на кнопки и ссылки.</li>
        </ul>
        <p>
          Подробные данные хранятся 90 дней, ежедневные сводки — один год. Эти данные
          записываются для всех посетителей, без cookie-файлов и без установления личности.
          Lovable собирает эти данные для нас.{" "}
          <a href="https://lovable.dev/privacy" target="_blank" rel="noopener noreferrer">
            Политика конфиденциальности Lovable
          </a>{" "}
          объясняет, как она с ними обращается.
        </p>
      </LegalSection>

      <LegalSection title="5. Внешние ссылки">
        <p>
          На сайте есть ссылки на Tribute и Telegram. Когда вы по ним переходите, начинают
          действовать правила этих сервисов. Если вы напишете нам в Telegram, переписка ведётся
          по правилам Telegram и используется только для ответа на ваш вопрос.
        </p>
      </LegalSection>

      <LegalSection title="6. Контакты">
        <p>
          По вопросам, связанным с этой политикой, пишите в Telegram:{" "}
          <a href={BOOK.support.url} target="_blank" rel="noopener noreferrer">
            @{BOOK.support.telegram}
          </a>
          .
        </p>
      </LegalSection>
    </LegalPage>
  );
}
