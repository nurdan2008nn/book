import { createFileRoute } from "@tanstack/react-router";

import { LegalPage, LegalSection } from "@/components/landing/LegalPage";
import { BOOK } from "@/config/book";

const TITLE = "Пользовательское соглашение и отказ от ответственности — Кодекс натурального здоровья";
const DESCRIPTION =
  "Условия покупки и использования электронной книги «Кодекс натурального здоровья»: информационный характер, противопоказания, доставка PDF и возврат.";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <LegalPage title="Пользовательское соглашение и отказ от ответственности">
      <LegalSection title="1. Характер издания">
        <p>
          Электронная книга «{BOOK.title}» (PDF, {BOOK.pages} страниц) является исключительно
          информационно-справочным изданием. Она не является медицинской услугой, диагностикой,
          лечением или врачебной рекомендацией.
        </p>
      </LegalSection>

      <LegalSection title="2. Информация «как есть»">
        <p>
          Вся информация предоставляется «как есть» для ознакомления. Покупатель самостоятельно
          оценивает риски, проверяет индивидуальную переносимость и возможные аллергические
          реакции перед использованием любых компонентов.
        </p>
      </LegalSection>

      <LegalSection title="3. Обязательная консультация с врачом">
        <p>Применение любых растительных средств допустимо только после очной консультации с врачом:</p>
        <ul>
          <li>при наличии хронических заболеваний;</li>
          <li>при приёме лекарств;</li>
          <li>при беременности и грудном вскармливании;</li>
          <li>для детей.</li>
        </ul>
      </LegalSection>

      <LegalSection title="4. Ограничение ответственности">
        <p>
          Автор и издатель не несут ответственности за последствия самостоятельного применения
          материалов книги без консультации со специалистом.
        </p>
      </LegalSection>

      <LegalSection title="5. Цифровой товар, доставка и возврат">
        <p>
          Товар является цифровым файлом (PDF). После оплаты он отправляется автоматически в
          Telegram через сервис Tribute. Печатная версия не отправляется. После предоставления
          доступа к файлу товар возврату не подлежит.
        </p>
      </LegalSection>

      <LegalSection title="6. Согласие с условиями">
        <p>
          Оплачивая книгу, вы подтверждаете, что ознакомились с этими условиями и принимаете их.
          Вопросы можно задать в Telegram:{" "}
          <a href={BOOK.support.url} target="_blank" rel="noopener noreferrer">
            @{BOOK.support.telegram}
          </a>
          .
        </p>
      </LegalSection>
    </LegalPage>
  );
}
