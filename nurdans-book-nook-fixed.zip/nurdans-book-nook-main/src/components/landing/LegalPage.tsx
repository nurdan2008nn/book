import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import type { ReactNode } from "react";

import { Button } from "@/components/ui/button";
import { BOOK } from "@/config/book";

export function LegalPage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto max-w-3xl px-5 py-8 md:py-12">
        <Link
          to="/"
          className="inline-flex items-center gap-2 font-semibold text-primary underline-offset-4 hover:underline"
        >
          <ArrowLeft className="size-5" aria-hidden /> Вернуться на главную
        </Link>

        <article className="frame-paper mt-6 rounded-3xl p-6 md:p-10">
          <p className="text-sm font-semibold uppercase tracking-[0.14em] text-gold">{BOOK.title}</p>
          <h1 className="mt-2 text-3xl font-bold md:text-4xl">{title}</h1>
          <div className="rule-botanical my-6" />
          <div className="legal-prose space-y-5">{children}</div>
        </article>

        <div className="mt-8 text-center">
          <Button asChild variant="hero" size="xl">
            <Link to="/">Вернуться на главную</Link>
          </Button>
        </div>
      </div>
    </main>
  );
}

export function LegalSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-3">
      <h2 className="text-xl font-bold md:text-2xl">{title}</h2>
      {children}
    </section>
  );
}
