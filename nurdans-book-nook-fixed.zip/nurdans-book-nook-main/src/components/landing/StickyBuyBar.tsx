import { Button } from "@/components/ui/button";
import { BOOK, formatPrice } from "@/config/book";
import { cn } from "@/lib/utils";

export function StickyBuyBar({ visible }: { visible: boolean }) {
  return (
    <div
      aria-hidden={!visible}
      className={cn(
        "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-paper/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur transition-transform duration-300 md:hidden",
        visible ? "translate-y-0" : "pointer-events-none translate-y-full",
      )}
    >
      <Button asChild variant="hero" size="xl" className="w-full">
        <a href="#buy" tabIndex={visible ? 0 : -1}>
          Забрать книгу за {formatPrice(BOOK.price)}
        </a>
      </Button>
    </div>
  );
}
