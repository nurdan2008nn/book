import { Check, Leaf, X } from "lucide-react";

import { AUDIENCE, COMPARISON, FACTS, HIGHLIGHTS } from "./content";

export function SectionHeading({
  eyebrow,
  title,
  lead,
}: {
  eyebrow: string;
  title: string;
  lead?: string;
}) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      <p className="text-sm font-semibold uppercase tracking-[0.14em] text-gold">{eyebrow}</p>
      <h2 className="mt-3 text-3xl font-bold md:text-4xl">{title}</h2>
      {lead && <p className="mt-4 text-lg text-foreground/80">{lead}</p>}
      <div className="rule-botanical mx-auto mt-4 w-40" />
    </div>
  );
}

export function Audience() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-10 md:py-14">
      <SectionHeading
        eyebrow="Для кого эта книга"
        title="Если вы узнаёте себя хотя бы в одном пункте"
      />
      <div className="mt-7 grid gap-4 md:grid-cols-2 md:gap-6">
        {AUDIENCE.map((item) => (
          <article
            key={item.n}
            className="flex gap-4 rounded-2xl border border-border bg-card p-6 md:p-7"
          >
            <span className="font-serif text-3xl font-bold leading-none text-gold">{item.n}</span>
            <div className="min-w-0">
              <h3 className="text-xl font-bold">{item.title}</h3>
              <p className="mt-2 text-foreground/85">{item.text}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export function Comparison() {
  return (
    <section className="bg-card/60 py-10 md:py-14">
      <div className="mx-auto max-w-5xl px-5">
        <SectionHeading
          eyebrow="Почему это безопаснее"
          title="Случайные советы из сети или выверенный справочник"
        />
        <div className="mt-7 overflow-hidden rounded-2xl border border-border bg-paper shadow-card">
          <div className="hidden grid-cols-2 border-b border-border text-sm font-semibold uppercase tracking-wider md:grid">
            <div className="px-6 py-4 text-muted-foreground">Советы из интернета</div>
            <div className="bg-primary px-6 py-4 text-primary-foreground">
              «Кодекс натурального здоровья»
            </div>
          </div>
          {COMPARISON.map((row, i) => (
            <div
              key={row.bad}
              className={`grid md:grid-cols-2 ${i > 0 ? "border-t border-border" : ""}`}
            >
              <div className="flex items-start gap-3 px-6 pb-2 pt-5 text-muted-foreground md:py-5">
                <X className="mt-1 size-5 shrink-0 text-destructive" aria-hidden />
                <span className="line-through decoration-destructive/40">{row.bad}</span>
              </div>
              <div className="flex items-start gap-3 px-6 pb-5 pt-2 font-semibold text-primary md:bg-accent/30 md:py-5">
                <Check className="mt-1 size-5 shrink-0" aria-hidden />
                <span>{row.good}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Inside() {
  const pages = [
    { src: "/images/promo_1_soderzhanie.png", caption: "Удобная карта всех 11 разделов", alt: "Страница содержания книги: 11 тематических разделов" },
    {
      src: "/images/promo_2_recept_55.png",
      caption: "Пример оформления рецепта: точные граммы, шаги и безопасность",
      alt: "Страница книги: рецепт №55 «Кардиопаста Пять семян» с ингредиентами, приготовлением и противопоказаниями",
    },
  ];
  return (
    <section className="mx-auto max-w-6xl px-5 py-10 md:py-14">
      <SectionHeading
        eyebrow="Загляните внутрь"
        title="Реальные страницы книги"
        lead="Так подробно оформлен каждый из 150 рецептов."
      />
      <div className="mt-7 grid gap-8 md:grid-cols-2">
        {pages.map((p) => (
          <figure key={p.src}>
            <img
              src={p.src}
              alt={p.alt}
              width={1080}
              height={1350}
              loading="lazy"
              className="w-full rounded-2xl border border-border shadow-card"
            />
            <figcaption className="mt-3 text-center font-serif text-lg italic text-primary">
              {p.caption}
            </figcaption>
          </figure>
        ))}
      </div>

      <div className="mt-10">
        <h3 className="text-center text-2xl font-bold md:text-3xl">
          Что вы найдёте на 170 страницах
        </h3>
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
          {FACTS.map((f) => (
            <div
              key={f.label}
              className="rounded-2xl border border-border bg-card p-5 text-center md:p-6"
            >
              <div className="font-serif text-4xl font-bold text-primary md:text-5xl">{f.value}</div>
              <div className="mt-2 text-base leading-snug text-foreground/85">{f.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Highlights() {
  return (
    <section className="bg-card/60 py-10 md:py-14">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading eyebrow="Чем удобна книга" title="За что её выбирают" />
        <div className="mt-7 grid gap-4 md:grid-cols-3 md:gap-6">
          {HIGHLIGHTS.map((h) => (
            <article key={h.title} className="rounded-2xl border border-border bg-paper p-6 shadow-card">
              <Leaf className="size-7 text-gold" aria-hidden />
              <h3 className="mt-3 text-xl font-bold">«{h.title}»</h3>
              <p className="mt-3 text-foreground/85">{h.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
