import { ArrowDown, BookOpen } from "lucide-react";
import { forwardRef } from "react";

import { Button } from "@/components/ui/button";
import { BOOK, formatPrice } from "@/config/book";

export const Hero = forwardRef<HTMLElement>(function Hero(_, ref) {
  return (
    <section ref={ref} className="bg-hero">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 pb-10 pt-6 md:grid-cols-[1.1fr_1fr] md:items-center md:gap-12 md:pb-14 md:pt-10">
        <div className="min-w-0">
          <p className="inline-flex items-start gap-2 rounded-2xl border border-border bg-paper px-4 py-2 text-sm font-medium leading-snug text-primary">
            <BookOpen className="mt-0.5 size-4 shrink-0" aria-hidden />
            <span>
              Электронный справочник • {BOOK.pages}&nbsp;страниц PDF • {BOOK.recipes}&nbsp;рецептов
            </span>
          </p>

          <h1 className="mt-5 text-[1.85rem] font-bold leading-[1.15] md:text-5xl">
            150 проверенных рецептов природы для дома —{" "}
            <span className="italic text-primary-deep">без догадок и опасных советов из интернета</span>
          </h1>

          {/* On mobile the cover sits right under the headline */}
          <CoverImage className="mt-7 md:hidden" />

          <p className="mt-6 text-lg text-foreground/85 md:text-xl">
            Настольная книга для 11 систем организма: простые ингредиенты из аптеки и магазина,
            точные пропорции в ложках и граммах, пошаговое приготовление и правила безопасности к
            каждому рецепту.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button asChild variant="hero" size="xl">
              <a href="#buy">Получить книгу — {formatPrice(BOOK.price)}</a>
            </Button>
            <Button asChild variant="paper" size="xl">
              <a href="#chapters">
                Посмотреть содержание <ArrowDown />
              </a>
            </Button>
          </div>
        </div>

        <CoverImage className="hidden md:block" />
      </div>
    </section>
  );
});

function CoverImage({ className = "" }: { className?: string }) {
  return (
    <div className={className}>
      <img
        src="/images/telegram_oblozhka_1600x1600.png"
        alt={`Обложка книги «${BOOK.title}» — ${BOOK.subtitle}`}
        width={1600}
        height={1600}
        fetchPriority="high"
        className="mx-auto w-full max-w-[18rem] rounded-3xl shadow-book sm:max-w-md md:max-w-none"
      />
    </div>
  );
}
