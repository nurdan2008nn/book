import { Check, ShieldCheck } from "lucide-react";

import { Button } from "@/components/ui/button";
import { BOOK, formatPrice } from "@/config/book";

const INCLUDED = [
  `PDF на русском языке, ${BOOK.pages} страниц`,
  `${BOOK.recipes} рецептов в ${BOOK.systems} разделах`,
  "Открывается на любом телефоне, планшете и компьютере",
  "Файл остаётся у вас навсегда",
];

const STEPS = [
  "Нажмите кнопку оплаты",
  "Оплатите в 1 клик через защищённый сервис Tribute",
  "Книга в формате PDF сразу придёт вам в Telegram",
];

export function Offer() {
  return (
    <section id="buy" className="mx-auto max-w-5xl px-5 py-10 md:py-14">
      <div className="frame-paper grid overflow-hidden rounded-3xl md:grid-cols-[0.9fr_1.1fr]">
        <div className="flex items-center justify-center bg-card p-6 md:p-10">
          <img
            src="/images/telegram_oblozhka_1600x1600.png"
            alt={`Обложка книги «${BOOK.title}»`}
            width={1600}
            height={1600}
            loading="lazy"
            className="mx-auto w-full max-w-xs rounded-2xl shadow-book md:max-w-sm"
          />
        </div>

        <div className="p-6 md:p-10">
          <p className="text-sm font-semibold uppercase tracking-[0.14em] text-gold">
            Электронная книга
          </p>
          <h2 className="mt-2 text-3xl font-bold md:text-4xl">{BOOK.title}</h2>

          <div className="mt-5 flex flex-wrap items-baseline gap-x-4 gap-y-1">
            {BOOK.oldPrice && (
              <span className="text-2xl text-muted-foreground line-through">
                {formatPrice(BOOK.oldPrice)}
              </span>
            )}
            <span className="font-serif text-5xl font-bold text-primary">
              {formatPrice(BOOK.price)}
            </span>
          </div>
          <p className="mt-1 text-foreground/80">Единоразовый платёж, без подписок</p>

          <ul className="mt-6 space-y-3">
            {INCLUDED.map((item) => (
              <li key={item} className="flex items-start gap-3">
                <Check className="mt-1 size-5 shrink-0 text-primary" aria-hidden />
                <span>{item}</span>
              </li>
            ))}
          </ul>

          <Button asChild variant="hero" size="xl" className="mt-8 w-full min-h-16 text-lg">
            <a href={BOOK.paymentUrl} target="_blank" rel="noopener noreferrer">
              Купить книгу за {formatPrice(BOOK.price)}
            </a>
          </Button>
          <p className="mt-3 flex items-center justify-center gap-2 text-sm text-foreground/75">
            <ShieldCheck className="size-4 shrink-0" aria-hidden />
            Безопасная оплата через Tribute
          </p>

          <ol className="mt-8 space-y-3 border-t border-border pt-6">
            {STEPS.map((step, i) => (
              <li key={step} className="flex items-start gap-3">
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-primary font-semibold text-primary-foreground">
                  {i + 1}
                </span>
                <span className="pt-0.5">{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
