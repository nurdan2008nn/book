import { Link } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { BOOK } from "@/config/book";

import { FAQ } from "./content";
import { SectionHeading } from "./Sections";

export function Faq() {
  return (
    <section className="bg-card/60 py-10 md:py-14">
      <div className="mx-auto max-w-3xl px-5">
        <SectionHeading eyebrow="Вопросы" title="Частые вопросы" />
        <Accordion type="single" collapsible className="mt-7 space-y-3">
          {FAQ.map((item, i) => (
            <AccordionItem
              key={item.q}
              value={`q${i}`}
              className="rounded-2xl border border-border bg-paper px-5"
            >
              <AccordionTrigger className="py-5 text-lg font-semibold text-primary hover:no-underline [&>svg]:size-5">
                {item.q}
              </AccordionTrigger>
              <AccordionContent className="pb-5 text-base text-foreground/85">
                {item.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-primary-deep pb-24 pt-10 text-primary-foreground md:pb-14">
      <div className="mx-auto max-w-3xl px-5 text-center">
        <p className="font-serif text-2xl font-bold">{BOOK.title}</p>
        <p className="mt-2 text-primary-foreground/85">Остались вопросы? Ответим в Telegram.</p>
        <Button asChild variant="gold" size="xl" className="mt-6">
          <a href={BOOK.support.url} target="_blank" rel="noopener noreferrer">
            <MessageCircle /> Написать в поддержку
          </a>
        </Button>
        <p className="mx-auto mt-7 max-w-2xl text-sm leading-relaxed text-primary-foreground/80">
          Издание электронное: вы получаете PDF-файл, печатная версия не отправляется. Материалы
          книги носят ознакомительный характер и не заменяют консультацию врача. Перед применением
          любого рецепта прочитайте противопоказания.
        </p>
        <nav className="mt-6 flex flex-col items-center gap-3 text-base sm:flex-row sm:justify-center sm:gap-6">
          <Link to="/privacy" className="underline underline-offset-4 hover:text-gold">
            Политика конфиденциальности
          </Link>
          <Link to="/terms" className="underline underline-offset-4 hover:text-gold">
            Пользовательское соглашение и отказ от ответственности
          </Link>
        </nav>
        <p className="mt-6 text-sm text-primary-foreground/70">
          © {new Date().getFullYear()} «{BOOK.title}»
        </p>
      </div>
    </footer>
  );
}
