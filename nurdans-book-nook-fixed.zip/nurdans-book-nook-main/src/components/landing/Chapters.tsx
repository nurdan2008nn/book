import { useState } from "react";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";

import { CHAPTERS } from "./content";
import { SectionHeading } from "./Sections";

const count = (c: (typeof CHAPTERS)[number]) => c.to - c.from + 1;

function RomanBadge({ roman, active = false }: { roman: string; active?: boolean }) {
  return (
    <span
      className={cn(
        "grid h-11 w-14 shrink-0 place-items-center rounded-lg font-serif text-base font-bold",
        active ? "bg-gold text-primary-deep" : "bg-primary text-primary-foreground",
      )}
    >
      {roman}
    </span>
  );
}

export function Chapters() {
  const [active, setActive] = useState(0);
  const current = CHAPTERS[active] ?? CHAPTERS[0];

  return (
    <section id="chapters" className="bg-card/60 py-10 md:py-14">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Содержание"
          title="Все 11 разделов книги"
          lead="Нажмите на раздел, чтобы увидеть, что внутри."
        />

        {/* Mobile: accordion */}
        <Accordion type="single" collapsible defaultValue="I" className="mt-7 space-y-3 md:hidden">
          {CHAPTERS.map((c) => (
            <AccordionItem
              key={c.roman}
              value={c.roman}
              className="rounded-2xl border border-border bg-paper px-4"
            >
              <AccordionTrigger className="gap-3 py-4 text-lg font-semibold text-primary hover:no-underline [&>svg]:size-5">
                <span className="flex min-w-0 items-center gap-3">
                  <RomanBadge roman={c.roman} />
                  <span className="min-w-0">{c.title}</span>
                </span>
              </AccordionTrigger>
              <AccordionContent className="pb-5 text-base">
                <p className="text-foreground/85">{c.text}</p>
                <p className="mt-2 font-semibold text-primary">
                  Рецепты №{c.from}–{c.to} · {count(c)} рецептов
                </p>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        {/* Desktop: list + detail panel */}
        <div className="mt-8 hidden gap-8 md:grid md:grid-cols-[1.2fr_1fr]">
          <ul className="grid grid-cols-1 gap-2.5 lg:grid-cols-2">
            {CHAPTERS.map((c, i) => (
              <li key={c.roman}>
                <button
                  type="button"
                  onClick={() => setActive(i)}
                  onMouseEnter={() => setActive(i)}
                  aria-pressed={i === active}
                  className={cn(
                    "flex w-full cursor-pointer items-center gap-3 rounded-xl border px-3 py-3 text-left transition-colors",
                    i === active
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-paper text-primary hover:border-primary/50",
                  )}
                >
                  <RomanBadge roman={c.roman} active={i === active} />
                  <span className="min-w-0 font-semibold leading-snug">{c.title}</span>
                </button>
              </li>
            ))}
          </ul>

          <div className="frame-paper sticky top-6 self-start rounded-2xl p-10">
            <p className="font-serif text-6xl font-bold text-gold">{current.roman}</p>
            <h3 className="mt-4 text-3xl font-bold">{current.title}</h3>
            <p className="mt-4 text-lg text-foreground/85">{current.text}</p>
            <div className="rule-botanical my-6" />
            <p className="text-lg font-semibold text-primary">
              Рецепты №{current.from}–{current.to}
            </p>
            <p className="text-muted-foreground">{count(current)} рецептов в разделе</p>
          </div>
        </div>
      </div>
    </section>
  );
}
