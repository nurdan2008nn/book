<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Путеводная звезда

У читателей есть понятное и безопасное руководство по домашним рецептам, которому они доверяют и которым пользуются.

## Метрика

Люди, купившие книгу, за неделю
